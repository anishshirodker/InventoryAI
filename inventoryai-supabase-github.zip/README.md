# Inventory AI — Supabase-connected GitHub Pages website

Repository: https://github.com/anishshirodker/inventoryai
Website (once Pages is enabled): https://anishshirodker.github.io/inventoryai/

## What's already deployed

- Supabase project `inventory-intelligence-ai` (`qoykhcoqwkykxfknwytf`)
- Database tables `inventory_reports`, `inventory_observations` with RLS enabled and no direct anonymous access
- Supabase Edge Function `inventory-api` (active)

## Step 1: Configure the administrator upload secret (required before uploads)

1. Open https://supabase.com/dashboard/project/qoykhcoqwkykxfknwytf/settings/functions
2. Find **Edge Function Secrets** (the exact dashboard location may change).
3. Add a secret named `INVENTORY_UPLOAD_SECRET` and give it a random, unique value of at least 32 characters. Use a password manager to generate and save it. Do NOT add it to GitHub or share it in chat.
4. Save/deploy the secret. The existing Edge Function reads this secret on upload requests.
5. Only the administrator needs this key to upload PDFs. Staff can view/search/export without a login or key.

## Step 2: Publish website

1. Extract the ZIP. Upload `index.html`, `app.js`, `style.css`, and `README.md` into the root of `anishshirodker/inventoryai` via **Add file > Upload files > Commit changes**.
2. GitHub repository **Settings > Pages > Deploy from a branch > main > /(root) > Save**.
3. Open https://anishshirodker.github.io/inventoryai/ after Pages finishes publishing.

## Step 3: Import history

1. On the website, enter the administrator upload key (the key stays in the current page only; it is not stored in localStorage or sent to GitHub).
2. Upload the In-Stock Detail PDFs for 2026-10-15 and 2026-10-29, one at a time. Confirm parsed row counts against the source reports.
3. On another computer, open the site and verify the same report history appears.

## Important limitations and security

- **Read access is public.** Anyone who knows the website or public API URL can read inventory data. Do not upload confidential store information without explicitly accepting this exposure. If inventory must be private, add staff authentication or restrict access through a private gateway before importing real reports.
- **Write access requires the administrator key.** This is deliberate. Anonymous uploads without a key or account cannot be safely restricted to your staff. Do not distribute the key to all staff unless you accept the risk of unauthorized uploads if it leaks.
- **No PDF data has been imported yet.** The previous browser-local sample history does not automatically migrate.
- **Parser needs acceptance testing** with the actual PDFs; UPCs, dates, MSL and average weekly sales should be cross-checked before operational reliance.
- **Stockout weeks** are distinct observed report dates with zero on-hand, not inferred weeks. Multiple reports on the same date are consolidated for metrics.
- If a large PDF upload fails partway through, retrying the same PDF resumes the unfinished report by file hash; partial reports are not shown to readers.
- Supabase free plan limits and Edge Function request limits may apply.
- The Edge Function source is in `supabase/functions/inventory-api/` for maintenance; the function has already been deployed separately and GitHub Pages does not execute it.
