import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.0';
const CORS = {'Access-Control-Allow-Origin':'https://anishshirodker.github.io','Access-Control-Allow-Headers':'content-type,x-upload-key','Access-Control-Allow-Methods':'GET,POST,OPTIONS','Content-Type':'application/json','Cache-Control':'no-store'};
const respond=(value:unknown,status=200)=>new Response(JSON.stringify(value),{status,headers:CORS});
const isSha=(s:unknown)=>typeof s==='string'&&/^[0-9a-f]{64}$/.test(s);
const isDate=(s:unknown)=>typeof s==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(s)&&!Number.isNaN(Date.parse(s));
const isUpc=(s:unknown)=>typeof s==='string'&&/^\d{8,14}$/.test(s);
const numeric=(v:unknown)=>v===null||v===undefined||v===''?null:(typeof v==='number'&&Number.isFinite(v)&&Math.abs(v)<1e12?v:NaN);
const admin=()=>createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false}});
Deno.serve(async req=>{
 if(req.method==='OPTIONS')return new Response(null,{headers:CORS});
 if(!['GET','POST'].includes(req.method))return respond({error:'Method not allowed'},405);
 try{
  const db=admin();
  if(req.method==='GET'){
   const url=new URL(req.url),kind=url.searchParams.get('kind')||'reports';
   if(kind==='reports'){
    const {data,error}=await db.from('inventory_reports').select('id,report_date,report_kind,file_sha256,source_filename,product_count').eq('upload_complete',true).order('report_date',{ascending:true}).limit(500);
    return error?respond({error:'Unable to retrieve reports'},500):respond({reports:data});
   }
   if(kind==='observations'){
    const id=url.searchParams.get('report_id');const offset=Number(url.searchParams.get('offset')||0);
    if(!id||! /^[0-9a-f-]{36}$/.test(id)||!Number.isInteger(offset)||offset<0||offset>1000000)return respond({error:'Invalid query'},400);
    const {data:report}=await db.from('inventory_reports').select('id').eq('id',id).eq('upload_complete',true).maybeSingle();
    if(!report)return respond({error:'Report not found'},404);
    const {data,error}=await db.from('inventory_observations').select('upc,description,department,planograms,on_hand,msl,avg_weekly_sales,qty_short').eq('report_id',id).order('upc').range(offset,offset+999);
    return error?respond({error:'Unable to retrieve observations'},500):respond({rows:data||[],next:(data?.length||0)===1000?offset+1000:null});
   }
   return respond({error:'Unknown query'},400);
  }
  const secret=Deno.env.get('INVENTORY_UPLOAD_SECRET');
  if(!secret||secret.length<24)return respond({error:'Uploads are not configured. Ask the administrator to set INVENTORY_UPLOAD_SECRET.'},503);
  const key=req.headers.get('x-upload-key')||'';
  const a=new TextEncoder().encode(secret),b=new TextEncoder().encode(key);
  let mismatch=a.length^b.length;for(let i=0;i<Math.max(a.length,b.length);i++)mismatch|=(a[i]||0)^(b[i]||0);
  if(mismatch)return respond({error:'Upload authorization failed'},403);
  const size=Number(req.headers.get('content-length')||0);if(size>900000)return respond({error:'Batch too large'},413);
  const body=await req.json();const action=body?.action;
  if(action==='begin'){
   const {id,date,scope,name,count}=body;
   if(!isSha(id)||!isDate(date)||!['all','zero'].includes(scope)||typeof name!=='string'||name.length>180||!Number.isInteger(count)||count<1||count>100000)return respond({error:'Invalid report metadata'},400);
   const {data:existing}=await db.from('inventory_reports').select('id,upload_complete').eq('file_sha256',id).maybeSingle();
   if(existing)return respond({report_id:existing.id,complete:existing.upload_complete,existing:true});
   const {data,error}=await db.from('inventory_reports').insert({file_sha256:id,report_date:date,report_kind:scope==='all'?'full':'zero_only',source_filename:name,product_count:count}).select('id').single();
   if(error)return respond({error:'Could not begin upload'},500);
   return respond({report_id:data.id,complete:false,existing:false});
  }
  if(action==='batch'){
   const {report_id,rows}=body;
   if(typeof report_id!=='string'||!Array.isArray(rows)||rows.length<1||rows.length>250)return respond({error:'Invalid batch'},400);
   const {data:report}=await db.from('inventory_reports').select('id,upload_complete').eq('id',report_id).maybeSingle();
   if(!report||report.upload_complete)return respond({error:'Report not open for upload'},409);
   const cleaned=[];
   for(const r of rows){
    if(!isUpc(r?.upc)||typeof r.name!=='string'||r.name.length>350||typeof r.department!=='string'||r.department.length>120)return respond({error:'Invalid product'},400);
    const on=numeric(r.onHand),msl=numeric(r.msl),sales=numeric(r.sales),short=numeric(r.short);
    if([on,msl,sales,short].some(Number.isNaN))return respond({error:'Invalid quantity'},400);
    cleaned.push({report_id,upc:r.upc,description:r.name,department:r.department,planograms:r.pog?[String(r.pog)]:[],on_hand:on,msl,avg_weekly_sales:sales,qty_short:short});
   }
   const {error}=await db.from('inventory_observations').upsert(cleaned,{onConflict:'report_id,upc'});
   return error?respond({error:'Unable to save batch'},500):respond({saved:cleaned.length});
  }
  if(action==='finish'){
   const {report_id}=body;
   if(typeof report_id!=='string')return respond({error:'Invalid report'},400);
   const {data:report}=await db.from('inventory_reports').select('id,product_count,upload_complete').eq('id',report_id).maybeSingle();
   if(!report||report.upload_complete)return respond({error:'Report not open'},409);
   const {count,error}=await db.from('inventory_observations').select('upc',{count:'exact',head:true}).eq('report_id',report_id);
   if(error||count!==report.product_count)return respond({error:`Upload incomplete: ${count??'?'} of ${report.product_count} rows`},409);
   const result=await db.from('inventory_reports').update({upload_complete:true}).eq('id',report_id).eq('upload_complete',false);
   return result.error?respond({error:'Could not finalize'},500):respond({complete:true});
  }
  return respond({error:'Unknown action'},400);
 }catch(e){console.error('inventory-api request error',e instanceof Error?e.message:'unknown');return respond({error:'Request could not be processed'},500)}
});
